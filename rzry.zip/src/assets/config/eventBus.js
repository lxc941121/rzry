import Vue from "Vue";

export default new Vue();
